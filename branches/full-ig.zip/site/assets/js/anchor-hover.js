anchors.options.visible = 'hover'
anchors.add()